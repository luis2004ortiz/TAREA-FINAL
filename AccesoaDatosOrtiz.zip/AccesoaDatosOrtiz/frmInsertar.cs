﻿using AccesoaDatosOrtiz.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccesoaDatosOrtiz
{
    public partial class frmInsertar : Form
    {
        public frmInsertar()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Estudiante estudiante = new Estudiante();

                estudiante.matricula = this.txtMatricula.Text;
                estudiante.apellido = this.txtApellidos.Text;
                estudiante.nombres = this.txtNombre.Text;
                estudiante.genero = this.cmbGenero.Text;
                estudiante.carrera = this.cmbCarreras.Text;
                estudiante.fechaNacimiento = this.dtFechadeNacimiento.Value;

                int x = EstudianteDAO.Guardar(estudiante);
                if (x > 0)
                    MessageBox.Show("Registro guardado con exito!!!");
                else
                    MessageBox.Show("no se pudo guardar el registro");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            this.txtMatricula.Clear();
            this.txtApellidos.Clear();
            this.txtNombre.Clear();
            this.cmbGenero.SelectedIndex = -1;
            this.cmbCarreras.SelectedIndex = 0;
            this.dtFechadeNacimiento.Value = DateTime.Now;
        }

        private void frmInsertar_Load(object sender, EventArgs e)
        {
            DataTable dt = CarreraDAO.getCarrera();

            this.cmbCarreras.DataSource = dt;
            this.cmbCarreras.ValueMember = "carrera"; 
            this.cmbCarreras.DisplayMember = "carrera";
        }
    }
}
