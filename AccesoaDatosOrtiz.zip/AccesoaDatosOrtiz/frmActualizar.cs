﻿using AccesoaDatosOrtiz.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccesoaDatosOrtiz
{
    public partial class frmActualizar : Form
    {
        public frmActualizar()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
           
            DataTable dt = EstudianteDAO.getEstudiante(this.txtMatricula.Text);

            if (dt.Rows.Count > 0)
            {
                DataRow fila = dt.Rows[0];
                this.txtApellidos.Text = fila["apellidos"].ToString();
                this.cmbCarreras.Text = fila["carrera"].ToString();
                this.cmbgenero.Text = fila["genero"].ToString();
                this.txtNombre.Text = fila["nombres"].ToString();
                this.dtFechadeNacimiento.Value = Convert.ToDateTime(fila["fechanacimiento"].ToString());
            }
            else
            {
                MessageBox.Show($"No existe el estudiante con la matrícula {this.txtMatricula.Text}");
            }
        }

        private void btnActualiar_Click(object sender, EventArgs e)
        {
            try
            {
                Estudiante estudiante = new Estudiante();

                estudiante.matricula = this.txtMatricula.Text;
                estudiante.apellido = this.txtApellidos.Text;
                estudiante.nombres = this.txtNombre.Text;
                estudiante.genero = this.cmbgenero.Text;
                estudiante.carrera = this.cmbCarreras.Text;
                estudiante.fechaNacimiento = this.dtFechadeNacimiento.Value;

                int x = EstudianteDAO.Actualizar(estudiante);
                if (x > 0)
                    MessageBox.Show("Registro guardado con exito!!!");
                else
                    MessageBox.Show("no se pudo guardar el registro");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmActualizar_Load(object sender, EventArgs e)
        {
            DataTable dt = CarreraDAO.getCarrera();

            this.cmbCarreras.DataSource = dt;
            this.cmbCarreras.ValueMember = "carrera"; //columna que quiero usar
            this.cmbCarreras.DisplayMember = "carrera"; //columna que quiero mostr
        }
    }
}
