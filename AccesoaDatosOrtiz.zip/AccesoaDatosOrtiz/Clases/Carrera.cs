﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoaDatosOrtiz.Clases
{
    public class Carrera
    {
        public int codCarrera { get; set; }
        public string carrera { get; set; }
    }
}
