﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoaDatosOrtiz.Clases
{
    public static class CarreraDAO
    {
        public static DataTable getCarrera()
        {
            //DEFINIR LA CONEXION
            string conexion = @"Server=.\SQLEXPRESS2019; database=RegistrodeNotas; Integrated Security=true";
            //string conexion = @"Sertver=E01-LCR-C09\PUCEDB; database=RegistrodeNotas; user id=sa; password=Esme.2024*";

            //Objeto para conectarse a la 8DD
            SqlConnection conn = new SqlConnection(conexion);

            //Sql que crea un registro
            string sql = "selec * from carrera";

            SqlDataAdapter adaptador = new SqlDataAdapter(sql, conn);

            //Declaro un datatable para recibir los datos 
            DataTable dataTable = new DataTable();

            //cargo los datos desde el adaptador al datatable
            adaptador.Fill(dataTable);

            return dataTable;
        }
    }
}
