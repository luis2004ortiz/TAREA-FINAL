﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoaDatosOrtiz.Clases
{
    public class EstudianteDAO
    {
        private static string conexion = @"Server=.\SQLEXPRESS2019; database=RegistrodeNotas; Integrated Security=true";

        public static int Guardar(Estudiante estudiante)
        {
            //DEFINIR LA CONEXION
            //string conexion = @"Sertver=.\SQLEXPRESS2019; database=RegistrodeNotas; Integrated Security=true";
            //string conexion = @"Sertver=.\SQLEXPRESS2019; database=RegistrodeNotas; user id=sa; password=123"

            //Objeto para conectarse a la 8DD
            SqlConnection conn = new SqlConnection(conexion);

            //Sql que crea un registro
            string sql = "insertar into Estudiante(matricula, apellidos, nombre, genero, fechaNacimiento, carrera) " +
                "values(@matricula,@apellido, @nombre, @genero, @fechaNacimiento, @carrera)";

            //Definir el comando sql que se va a ejecutar en la 8DD (en este caso insertar o crear
            SqlCommand comando = new SqlCommand(sql, conn);

            //abrimos la conexion 
            conn.Open();

            //remplazo parametros
            comando.Parameters.Add(new SqlParameter("@matricula", estudiante.matricula));
            comando.Parameters.Add(new SqlParameter("@apellido", estudiante.apellido));
            comando.Parameters.Add(new SqlParameter("@nombres", estudiante.nombres));
            comando.Parameters.Add(new SqlParameter("@genero", estudiante.genero));
            comando.Parameters.Add(new SqlParameter("@carrera", estudiante.carrera));
            comando.Parameters.Add(new SqlParameter("@fechaNacimiento", estudiante.fechaNacimiento));

            //ejecuto el comando
            int x = comando.ExecuteNonQuery();

            //cerramos la conexion
            conn.Close();

            return x;
        }
        public static DataTable getEstudiante(string matricula)
        {
            //DEFINIR LA CONEXION
            //string conexion = @"Sertver=.\SQLEXPRESS2019; database=RegistrodeNotas; Integrated Security=true";
            //string conexion = @"Sertver=E01-LCR-C09\PUCEDB; database=RegistrodeNotas; user id=sa; password=Esme.2024*";

            //Objeto para conectarse a la 8DD
            SqlConnection conn = new SqlConnection(conexion);

            //Sql que crea un registro
            string sql = "select * from Estudiante where matricula=@matricula";

            SqlDataAdapter adaptador = new SqlDataAdapter(sql, conn);
            adaptador.SelectCommand.Parameters.Add(new SqlParameter("@matricula", matricula));

            //Declaro un datatable para recibir los datos 
            DataTable dataTable = new DataTable();

            //cargo los datos desde el adaptador al datatable
            adaptador.Fill(dataTable);

            return dataTable;
        }

        public int eliminar(string matricula)
        {
            SqlConnection conn = new SqlConnection(conexion);

            string sql = "DELETE FROM Estudiante WHERE matricula = @matricula";
            SqlCommand comando = new SqlCommand(sql, conn);

            conn.Open();

            comando.Parameters.Add(new SqlParameter("@matricula", matricula));

            int resultado = comando.ExecuteNonQuery();

            conn.Close();

            return resultado;
        }

        public static int Actualizar(Estudiante estudiante)
        {
            SqlConnection conn = new SqlConnection(conexion);

            string sql = "update Estudiante set apellido=@apellido, nombres=@nombres, genero=@genero, fechaNacimiento=@fechaNacimiento, carrera=@carrera " +
                "where matricula=@matricula";

            SqlCommand comando = new SqlCommand(sql, conn);

            conn.Open();

            comando.Parameters.Add(new SqlParameter("@matricula", estudiante.matricula));
            comando.Parameters.Add(new SqlParameter("@apellido", estudiante.apellido));
            comando.Parameters.Add(new SqlParameter("@nombres", estudiante.nombres));
            comando.Parameters.Add(new SqlParameter("@genero", estudiante.genero));
            comando.Parameters.Add(new SqlParameter("@carrera", estudiante.carrera));
            comando.Parameters.Add(new SqlParameter("@fechaNacimiento", estudiante.fechaNacimiento));

            int resultado = comando.ExecuteNonQuery();

            conn.Close();

            return resultado;
        }
    }
}
