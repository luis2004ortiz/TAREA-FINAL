﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoaDatosOrtiz.Clases
{
    public class Estudiante
    {
        public string matricula { get; set; }
        public string apellido { get; set; }
        public string nombres { get; set; }
        public string genero { get; set; }
        public DateTime fechaNacimiento { get; set; }
        public string carrera { get; set; }

    }
}
