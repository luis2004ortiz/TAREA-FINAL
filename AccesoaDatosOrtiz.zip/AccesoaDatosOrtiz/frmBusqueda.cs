﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccesoaDatosOrtiz
{
    public partial class frmBusqueda : Form
    {
        public frmBusqueda()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            DataTable dt = AccesoaDatosOrtiz.EstudianteDAO. getEstudiante(this.txtMatricula.Text);

            if (dt.Rows.Count > 0)
            {
                DataRow fila = dt.Rows[0];
                this.txtApellidos.Text = fila["apellidos"].ToString();
                this.cmbCarreras.Text = fila["carrera"].ToString();
                this.cmbgenero.Text = fila["genero"].ToString();
                this.txtNombre.Text = fila["nombres"].ToString();
                this.dtFechadeNacimiento.Value = Convert.ToDateTime(fila["fechanacimiento"].ToString());
            }
            else
            {
                MessageBox.Show($"No existe el estudiante con la matrícula {this.txtMatricula.Text}");
            }
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("¿quieres eliminar estos datos?");

            string matricula = this.txtMatricula.Text;

            if (matricula == "")
            {
                MessageBox.Show("Ingrese una matricula.");
            }
            else
            {
                if (result == DialogResult.Yes)
                {
                    EstudianteDAO oEst = new EstudianteDAO();
                    int x = oEst.eliminar(matricula);

                    if (x > 0)
                    {
                        MessageBox.Show("Datos eliminados");
                        this.txtApellidos.Clear();
                        this.txtNombre.Clear();
                        this.cmbgenero.Clear();
                        this.dtFechadeNacimiento.Value = DateTime.Now;
                        this.cmbCarreras.Clear();
                        this.txtMatricula.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Error");
                    }
                }
    }
}

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
